<fieldset class="inline-edit-col-right">
    <div class="inline-edit-col">
        <div class="inline-edit-group">
            <label for="sep_exclude">
                <input type="hidden" name="sep[hidden]" id="sep_hidden" value="1" />
                <input type="checkbox" name="sep[exclude]" id="sep_exclude" value="1" />
                <span class="checkbox-title">Exclude from Search Results</span>
            </label>
        </div>
    </div>
</fieldset>