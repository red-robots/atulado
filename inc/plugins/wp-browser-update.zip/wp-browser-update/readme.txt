=== WP BrowserUpdate ===
Contributors: MacSteini
Tags: Browser, Update, Installation, Notice, Warning, Out-dated
Requires at least: 2.0
Tested up to: 5.2
Compatible up to: 5.2
Stable tag: 4.0

License: GPLv3 or later
License URI: http://gnu.org/licenses/gpl

This plugin informs website visitors to update their out-dated browser in an unobtrusive way.

== Description ==
Many internet users are surfing with out-dated browsers for several reasons (mainly because they do not know how to update). Switching to a newer browser is better in terms of security and reliability. This plugin informs your visitors to switch to a newer browser in an unobtrusive way. Just activate this plugin and you and your visitors are good to go…

Go to <a href="http://browser-update.org/" title="browser-update.org" target="_blank">browser-update.org</a> for more information.

If you wish to translate this plugin into your language, please visit the <a href="http://translate.wordpress.org/projects/wp-plugins/wp-browser-update" title="Translating WordPress" target="_blank">Translating WordPress Project</a> page for details and how to. Appreciate your support!

== Installation ==
= Manually =
Unzip wp-browser-update.zip and upload the unzipped folder to /wp-content/plugins/ directory of your WordPress installation.

= Via Plugin Backend =
Upload wp-browser-update.zip from your plugin panel (/wp-admin/plugin-install.php?tab=upload).

= Via Plugin Search =
Search for “wp browserupdate” and install the displayed result from your plugin panel (/wp-admin/plugin-install.php).

= Activation =
Don’t forget to activate WP BrowserUpdate afterwards. ;-)

== Changelog ==
= 4.0 =
* Bug fix (thanks to the commenters on the support forum)
* Updated JavaScript

= 3.2 =
* Corrected typo in version number which rendered this plugin to be outdated

= 3.1.2 =
* Updated (out-dated) browser versions

= 3.1.1 =
* Updated (out-dated) browser versions

= 3.1 =
* Bug fix (thanks to <a href="http://wordpress.org/support/users/tristanmason" title="@tristanmason’s Profile" target="_blank">@tristanmason</a>)
* Updated (out-dated) browser versions

= 3.0.3 =
* Updated (out-dated) browser versions

= 3.0.2 =
* Corrected initialisation error
* Protocol changed from HTTP to HTTPS

= 3.0.1 =
* Updated (out-dated) browser versions

= 3.0 =
* Overhauled functions
* Updated JavaScript
* Updated (out-dated) browser versions

= 2.4.1 =
* Updated (out-dated) browser versions

= 2.4 =
* Corrected functions

= 2.3 =
* Overhauled functions
* Updated translation files

= 2.2.1 =
* Minor bug fix

= 2.2 =
* Changed license from GPLv2 to GPLv3
* Added text domain in plugin header
* Added POT file in ./languages folder for easier i18n ;-)

= 2.1.3 =
* Included minified JavaScript (forgot to switch back after some testing)

= 2.1.2 =
* Updated (out-dated) browser versions

= 2.1.1 =
* Minor fix of initial notification message (thanks to Matthias Van Dooren)

= 2.1 =
* Added options to customize the JavaScript (thanks to Tomas Risberg)

= 2.0.3 =
* Updated (out-dated) browser versions
* Updated JavaScript

= 2.0.2 =
* Added settings link to plugin overview page

= 2.0.1 =
* Minor bug fix

= 2.0 =
* Added administration panel for individual modifications
* Added uninstall function

= 1.0 =
* Stable version